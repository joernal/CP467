package assignment;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.io.*;
import java.util.ArrayList;

import javax.imageio.*;
import javax.swing.*;

import assignment.pixel;
import assignment.symbol;
import java.util.List;


public class ocr {

  public static void main(String []args){ 
    BufferedImage img = null;
    List<symbol> syms = new ArrayList<symbol>();
    
    int counter = 0;

    int merge1index = -1;
    int merge2index = -1;
 
    try {
      img = ImageIO.read(new File("image.bmp"));
      boolean value = false;
      if (img.getWidth() > 0){
        System.out.println("Got image!");
        int grayscale = 0;
        for (int yPixel = 0; yPixel < img.getHeight(); yPixel++){

          for (int xPixel = 0 ; xPixel < img.getWidth(); xPixel++){

            int color = img.getRGB(xPixel, yPixel);
            if (color==Color.BLACK.getRGB()){
            	counter++;
            	//System.out.println("test counter" + counter);
            	pixel pix = new pixel(xPixel, yPixel, grayscale);
            	//System.out.println("x=" + pix.x + " y=" + pix.y);
            	if (syms.size()!=0){
            		outerloop:
            		for (int i = 0; i < syms.size(); i++){ 
            			//System.out.println("symbol size before search"+syms.size());
            			//System.out.println("test");
            			if (syms.get(i).searchSymbol(pix)==true){
            				//System.out.println("FOUND IT");

            				
            				merge1index = i;
            				for (int j = syms.size()-1; j >= 0; j--){ 
            					if (syms.get(j).searchSymbol(pix)==true){
            						value = true;
            						if(i!=j){
            							merge2index=j;
            							syms=merge(syms, i, j, pix);
            							merge1index = merge2index = -1;
            							break outerloop;
            						}else{
                        				syms.get(i).addPixel(pix);
            							break outerloop;
            						}
            						
            					}
            				}
            				
            			}else{
            				value = false;
            			}
            			
            		}
            		
            		if (value != true){
            			symbol s = new symbol();
            			s.addPixel(pix);
            			syms.add(s);
            			
            		}
            		
            	}else{
            		symbol s = new symbol();
            		s.addPixel(pix);
            		syms.add(s);
            	}
            	
            	              
            }

          }

        }
        System.out.println("Total number of Black Pixels: " + counter);
        
        for (int k=0; k<syms.size(); k++){
        	System.out.println("Number of black pixels in symbol " + k + " is " + syms.get(k).list_of_pixels.size());
        	
        	/*//FOR TESTING PURPOSES ONLY
        	int size = syms.get(k).list_of_pixels.size();
        	 for (int l=0; l<size; l++){
        		 System.out.println("coordinates are x = " +syms.get(k).list_of_pixels.get(l).x + " y = " +syms.get(k).list_of_pixels.get(l).y);
        	 }
        	 */
        	
        }
        
        // Convolution
        
        
       convolute(img);
        
      } else {
        System.out.println("No Image!");
      }
    } catch (IOException e){
      System.out.println("Image not found!");
    }
  }
  
  public static List<symbol> merge(List<symbol> syms, int i, int j, pixel pix){
	  for (int k = 0; k<syms.get(i).list_of_pixels.size(); k++){
		  syms.get(j).list_of_pixels.add(syms.get(i).list_of_pixels.get(k));
	  }
	  syms.get(j).list_of_pixels.add(pix);
	  syms.remove(i);
	  return syms;
  }
  
  public static void convolute(BufferedImage img){
	  
	  int padding = 2;
	  
	  List<pixel> pixels = new ArrayList<pixel>();
	  
	  BufferedImage newImage = new BufferedImage(img.getWidth()+2*padding, img.getHeight()+2*padding, img.getType());
	  // add padding around image
	  Graphics g1 = newImage.getGraphics();

	  g1.setColor(Color.white);
	  g1.fillRect(0,0,img.getWidth()+2*padding,img.getHeight()+2*padding);
	  g1.drawImage(img, padding, padding, null);
	  g1.dispose();


	  int rgb;
	  double[][] pixData = new double[newImage.getWidth()][newImage.getHeight()];
      for (int yPixel = 0; yPixel < newImage.getHeight(); yPixel++){

          for (int xPixel = 0 ; xPixel < newImage.getWidth(); xPixel++){
		        rgb = newImage.getRGB(xPixel, yPixel);
		        
		        int r = (rgb >> 16) & 0xFF;
		        int g = (rgb >> 8) & 0xFF;
		        int b = (rgb & 0xFF);
		        
		        int gray = (r + g + b) / 3;  // get gray value

		        pixData[xPixel][yPixel] = gray;
		        
		        
		        
		    }
	  }
      
      for (int y = 0; y < newImage.getHeight(); y++){
    	  for (int x=0; x < newImage.getWidth()-4; x++){
    		  pixData[x+2][y] = 0.2*pixData[x][y] +
    				  			0.2*pixData[x+1][y] +
    				  			0.2*pixData[x+2][y] +
    				  			0.2*pixData[x+3][y] +
    				  			0.2*pixData[x+4][y];
    		  newImage.setRGB(x, y, ((int) (pixData[x+2][y]) * 0x00010101) );
    	  }
      }
      
      for (int x=0; x < newImage.getWidth(); x++){
    	  for (int y = 0; y < newImage.getHeight()-4; y++){
    		  pixData[x][y+2] = 0.2*pixData[x][y] +
    				  			0.2*pixData[x][y+1] +
    				  			0.2*pixData[x][y+2] +
    				  			0.2*pixData[x][y+3] +
    				  			0.2*pixData[x][y+4];
    		  newImage.setRGB(x, y, ((int) (pixData[x][y+2]) * 0x00010101) );
    	  }
      }
      
	  newImage = newImage.getSubimage(2, 2, img.getWidth(), img.getHeight());

	  							
	  try{
		  File outputfile = new File("convoluted.bmp");
		  ImageIO.write(newImage, "bmp", outputfile);
	  }catch (IOException e) {
	    System.out.println("Image not saved!");
	  }


  }

}
