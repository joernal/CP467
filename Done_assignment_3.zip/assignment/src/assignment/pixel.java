package assignment;

public class pixel {
	int x,y;
	double grayscale;
	public pixel(int x, int y, double grayscale){
		this.x = x;
		this.y = y;
		this.grayscale = grayscale;
	}
}
